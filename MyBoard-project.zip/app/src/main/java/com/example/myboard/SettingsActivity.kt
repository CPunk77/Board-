package com.example.myboard

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    private val p by lazy { Cfg.prefs(this) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); Cfg.load(this)
        val me = this
        val col = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(24), dp(18), dp(48)) }
        setContentView(ScrollView(me).apply { addView(col) })

        fun label(t: String, size: Float = 16f, top: Int = 18) =
            col.addView(TextView(me).apply { text = t; textSize = size; setPadding(0, dp(top), 0, dp(6)) })
        fun btn(t: String, f: () -> Unit) =
            col.addView(Button(me).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
        fun sw(title: String, key: String, def: Boolean) = col.addView(Switch(me).apply {
            text = title; isChecked = p.getBoolean(key, def); setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean(key, v).apply() }
        })
        fun slider(title: String, key: String, lo: Int, hi: Int, def: Int) {
            val tv = TextView(me).apply { setPadding(0, dp(14), 0, 0) }
            val cur = p.getInt(key, def); tv.text = "$title: $cur"
            col.addView(tv)
            col.addView(SeekBar(me).apply {
                this.max = hi - lo; progress = cur - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { p.edit().putInt(key, v + lo).apply(); tv.text = "$title: ${v + lo}" }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }

        label("Моя клавиатура", 24f, 0)
        btn("1. Включить клавиатуру") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        btn("2. Выбрать клавиатуру") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        col.addView(EditText(me).apply { hint = "Попробуй здесь…"; minLines = 2 })
        label("Изменения применяются при следующем открытии клавиатуры.", 13f, 4)

        label("Тема и цвет")
        val tbs = ArrayList<Button>(); val cbs = ArrayList<Button>()
        fun paint() {
            tbs.forEachIndexed { i, b -> b.alpha = if (THEMES[i] === Cfg.theme) 1f else .4f }
            cbs.forEachIndexed { i, b -> b.alpha = if (ACCENTS[i].toInt() == Cfg.accent) 1f else .4f }
        }
        val tr = LinearLayout(me); val cr = LinearLayout(me); col.addView(tr); col.addView(cr)
        listOf("Лес", "AMOLED", "Светлая", "Ночь").forEachIndexed { i, n ->
            val b = Button(me).apply {
                this.text = n; textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0
                setOnClickListener { p.edit().putInt("theme", i).apply(); Cfg.load(me); paint() }
            }
            tbs.add(b); tr.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        ACCENTS.forEachIndexed { i, c ->
            val b = Button(me).apply {
                minWidth = 0; minimumWidth = 0
                background = GradientDrawable().apply { setColor(c.toInt()); cornerRadius = dp(10).toFloat() }
                setOnClickListener { p.edit().putInt("accent", c.toInt()).apply(); Cfg.load(me); paint() }
            }
            cbs.add(b); cr.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
        }
        paint()

        label("Размер")
        slider("Высота клавиатуры (dp)", "h", 200, 340, 260)
        slider("Скругление клавиш (dp)", "r", 0, 18, 9)

        label("Скорость набора")
        sw("Умное попадание по клавишам (учитывает словарь)", "smart", true)
        sw("Свайп-печать", "glide", true)
        sw("Автоисправление", "fix", true)
        sw("Смах вниз по клавише — цифра или символ", "hints", true)
        sw("Показывать буфер обмена в подсказках", "clip", true)
        label("Внешний вид и отклик")
        sw("Вибрация", "vib", true)
        sw("Ряд цифр сверху", "num", true)

        label("Сокращения: сокращение=текст, по одному в строке")
        val ed = EditText(me).apply { setText(p.getString("snip", DEF_SNIP)); minLines = 6; gravity = Gravity.TOP }
        col.addView(ed)
        btn("Сохранить сокращения") {
            p.edit().putString("snip", ed.text.toString()).apply()
            Toast.makeText(me, "Сохранено", Toast.LENGTH_SHORT).show()
        }
    }
}
