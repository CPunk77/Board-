package com.example.myboard

import android.content.Context
import android.content.SharedPreferences

class Theme(b: Long, k: Long, f: Long, t: Long, s: Long) {
    val bg = b.toInt(); val key = k.toInt(); val fn = f.toInt(); val tx = t.toInt(); val sub = s.toInt()
}

val THEMES = listOf(
    Theme(0xFF161D1B, 0xFF27312E, 0xFF1F2825, 0xFFEDF1EE, 0xFF93A19A),
    Theme(0xFF000000, 0xFF1C1C1E, 0xFF111113, 0xFFFFFFFF, 0xFF8E8E93),
    Theme(0xFFE3E8E1, 0xFFFBFCFA, 0xFFCBD3CB, 0xFF1B2421, 0xFF5B6862),
    Theme(0xFF0F1626, 0xFF1F2A44, 0xFF182036, 0xFFE8EDFA, 0xFF8C9AB8)
)
val ACCENTS = longArrayOf(0xFFF2B544, 0xFF2DD4BF, 0xFFFB7185, 0xFFA78BFA, 0xFF38BDF8, 0xFFA3E635)

const val DEF_SNIP = "мб=может быть\nспс=спасибо\nпжл=пожалуйста\nсч=сейчас\nчз=через\nхз=не знаю\nbtw=by the way\nomw=on my way"

object Cfg {
    var theme = THEMES[0]; var accent = ACCENTS[0].toInt()
    var h = 260; var r = 9
    var vib = true; var num = true; var hints = true; var fix = true; var glide = true; var clip = true; var smart = true
    var snip: Map<String, String> = emptyMap()

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("board", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val p = prefs(c)
        theme = THEMES[p.getInt("theme", 0).coerceIn(0, THEMES.size - 1)]
        accent = p.getInt("accent", ACCENTS[0].toInt())
        h = p.getInt("h", 260); r = p.getInt("r", 9)
        vib = p.getBoolean("vib", true); num = p.getBoolean("num", true); hints = p.getBoolean("hints", true)
        fix = p.getBoolean("fix", true); glide = p.getBoolean("glide", true)
        clip = p.getBoolean("clip", true); smart = p.getBoolean("smart", true)
        snip = (p.getString("snip", DEF_SNIP) ?: "").lines().mapNotNull {
            val i = it.indexOf('=')
            if (i > 0 && i < it.length - 1) it.substring(0, i).trim().lowercase() to it.substring(i + 1).trim() else null
        }.toMap()
    }
}
