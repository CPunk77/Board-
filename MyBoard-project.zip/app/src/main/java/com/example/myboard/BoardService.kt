package com.example.myboard

import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class Sug(val x: String, val on: Boolean = false, val lit: Boolean = false, val rep: Int = 0)
class Undo(val o: String, val f: String, val b: String)

class BoardService : InputMethodService() {
    var lang = 0
    var sym = false
    var sh = 0 // 0 выкл, 1 одна заглавная, 2 caps lock
    val dict = ArrayList<String>()
    val user = HashMap<String, Int>()
    private val dset = HashSet<String>()
    private val big = HashMap<String, Int>()
    private lateinit var keys: KeysView
    private lateinit var bar: LinearLayout
    private var gAlt: List<String> = emptyList()
    private var gCur = ""
    private var undo: Undo? = null
    private var lastSp = 0L
    private val prefs by lazy { getSharedPreferences("board", MODE_PRIVATE) }
    private val wordRe = Regex("""[\p{L}’'-]+$""")

    override fun onCreate() {
        super.onCreate()
        assets.open("words.txt").bufferedReader().useLines { ls -> ls.filter { it.isNotBlank() }.forEach { dict.add(it.trim()) } }
        dset.addAll(dict)
        load("u", user); load("b", big)
        "как дела,спасибо большое,добрый день,до встречи,thank you,how are,see you,let me".split(",").forEach { if (it !in big) big[it] = 1 }
    }

    private fun load(k: String, m: HashMap<String, Int>) {
        prefs.getString(k, "")!!.lines().forEach { val p = it.split("\t"); if (p.size == 2) m[p[0]] = p[1].toIntOrNull() ?: 0 }
    }
    private fun save(k: String, m: Map<String, Int>) {
        prefs.edit().putString(k, m.entries.joinToString("\n") { "${it.key}\t${it.value}" }).apply()
    }
    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput); save("u", user); save("b", big)
    }

    fun dpi(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF161D1B.toInt()); clipChildren = false }
        bar = LinearLayout(this)
        repeat(3) { bar.addView(TextView(this).apply { gravity = Gravity.CENTER; textSize = 16f; maxLines = 1 }, LinearLayout.LayoutParams(0, dpi(42), 1f)) }
        keys = KeysView(this, this)
        root.addView(bar)
        root.addView(keys, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(250)))
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting); sh = 0; gAlt = emptyList(); undo = null; refresh()
    }

    fun refresh() {
        if (!::keys.isInitialized) return
        keys.invalidate()
        val s = suggest()
        for (i in 0 until 3) {
            val tv = bar.getChildAt(i) as TextView; val g = s.getOrNull(i)
            tv.text = if (g == null) "" else if (g.lit) "«${g.x}»" else g.x
            tv.setTextColor(if (g?.on == true) 0xFFF2B544.toInt() else if (g?.lit == true) 0xFF93A19A.toInt() else 0xFFEDF1EE.toInt())
            tv.setOnClickListener(if (g == null) null else View.OnClickListener { pick(g) })
        }
    }

    private fun before(n: Int) = currentInputConnection?.getTextBeforeCursor(n, 0)?.toString() ?: ""
    private fun cap(w: String) = w.replaceFirstChar { it.uppercase() }
    fun caps(): Boolean = sh != 0 || (!sym && (currentInputConnection?.getCursorCapsMode(currentInputEditorInfo?.inputType ?: 0) ?: 0) != 0)
    fun words(): List<String> = (dict + user.keys).distinct()

    // ---- автоисправление: одна правка (замена, вставка, удаление, перестановка) ----
    private fun ed1(a: String, b: String): Boolean {
        val n = a.length; val m = b.length
        if (a == b || abs(n - m) > 1) return false
        var i = 0; while (i < n && i < m && a[i] == b[i]) i++
        return if (n == m) a.substring(i + 1) == b.substring(i + 1) ||
            (i + 1 < n && a[i] == b[i + 1] && a[i + 1] == b[i] && a.substring(i + 2) == b.substring(i + 2))
        else if (n > m) a.substring(i + 1) == b.substring(i) else a.substring(i) == b.substring(i + 1)
    }
    private fun fixOf(l: String): String? =
        if (l.length < 4 || l in dset || user.containsKey(l)) null
        else dict.firstOrNull { (it[0] == l[0] || it.length == l.length) && ed1(l, it) }

    private fun fix(ic: InputConnection): Pair<String, String>? {
        val w = wordRe.find(before(40))?.value ?: return null
        val c = fixOf(w.lowercase()) ?: return null
        val x = if (w[0].isUpperCase()) cap(c) else c
        ic.deleteSurroundingText(w.length, 0); ic.commitText(x, 1)
        return w to x
    }

    private fun learn() {
        val sl = before(61)
        if (sl.isEmpty() || !sl.last().isLetter()) return
        val k = Regex("""[\p{L}’'-]+""").findAll(sl.lowercase()).map { it.value }.toList()
        val w = k.last(); val p = k.getOrNull(k.size - 2)
        if (w.length > 2) user[w] = (user[w] ?: 0) + 1
        if (p != null && w.length > 1) { val q = "$p $w"; big[q] = (big[q] ?: 0) + 1 }
    }

    // ---- подсказки ----
    private fun suggest(): List<Sug> {
        val pre = before(60); val out = ArrayList<Sug>()
        if (gAlt.isNotEmpty() && pre.endsWith("$gCur ")) return gAlt.take(3).mapIndexed { i, w -> Sug(w, i == 0, false, gCur.length + 1) }
        val w0 = wordRe.find(pre)?.value ?: ""; val p = w0.lowercase()
        if (p.isNotEmpty()) {
            val lc = fixOf(p); val up = w0[0].isUpperCase()
            val cs = { w: String -> if (up) cap(w) else w }
            if (lc != null) { out.add(Sug(w0, lit = true, rep = p.length)); out.add(Sug(cs(lc), on = true, rep = p.length)) }
            val c = (user.keys.filter { it.startsWith(p) && it != p }.sortedByDescending { user[it] } +
                dict.asSequence().filter { it.startsWith(p) && it != p }.take(6).toList()).distinct().filter { it != lc }
            c.take(3).forEachIndexed { i, w -> out.add(Sug(cs(w), lc == null && i == 0, false, p.length)) }
        } else {
            val lw = Regex("""([\p{L}’'-]+)\s$""").find(pre.lowercase())?.groupValues?.get(1)
            val c = caps(); val cs = { w: String -> if (c) cap(w) else w }
            val nx = if (lw == null) emptyList() else big.entries.filter { it.key.startsWith("$lw ") }.sortedByDescending { it.value }.map { it.key.substring(lw.length + 1) }
            (nx + (if (lang == 0) listOf("привет", "спасибо", "давай") else listOf("hello", "thanks", "sure")))
                .distinct().take(3).forEachIndexed { i, w -> out.add(Sug(cs(w), i == 0)) }
        }
        return out.take(3)
    }

    private fun pick(g: Sug) {
        val ic = currentInputConnection ?: return
        if (g.lit) user[g.x.lowercase()] = 2
        gAlt = emptyList(); undo = null
        ic.deleteSurroundingText(g.rep, 0); ic.commitText(g.x, 1); learn(); ic.commitText(" ", 1); refresh()
    }

    // ---- ввод ----
    fun typeChar(v: String, flick: Boolean, alt: String?) {
        var c = alt ?: v
        if (c[0].isLetter() && (flick || caps())) c = c.uppercase()
        if (sh == 1) sh = 0
        type(c)
    }

    private fun type(t: String) {
        val ic = currentInputConnection ?: return
        gAlt = emptyList(); undo = null
        val bnd = t.length == 1 && !(t[0].isLetterOrDigit() || t[0] == '\'' || t[0] == '’' || t[0] == '-')
        val f = if (bnd) fix(ic) else null
        if (bnd) learn()
        ic.commitText(t, 1)
        if (f != null) undo = Undo(f.first, f.second, t)
        refresh()
    }

    fun space() {
        val n = SystemClock.uptimeMillis(); val ic = currentInputConnection ?: return
        if (n - lastSp < 380 && Regex("""[\p{L}\p{N}] $""").containsMatchIn(before(2))) {
            ic.deleteSurroundingText(1, 0); ic.commitText(". ", 1); undo = null; gAlt = emptyList(); refresh()
        } else type(" ")
        lastSp = n
    }

    fun enter() {
        val ic = currentInputConnection ?: return
        fix(ic); learn(); undo = null; gAlt = emptyList()
        if (!sendDefaultEditorAction(true)) ic.commitText("\n", 1)
        refresh()
    }

    fun backspace() {
        val ic = currentInputConnection ?: return
        gAlt = emptyList()
        val u = undo
        if (u != null && before(u.f.length + 1) == u.f + u.b) { // откат автоисправления
            ic.deleteSurroundingText(u.f.length + 1, 0); ic.commitText(u.o, 1); user[u.o.lowercase()] = 2; undo = null; refresh(); return
        }
        undo = null
        if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingTextInCodePoints(1, 0)
        refresh()
    }

    fun backspaceWord() {
        val ic = currentInputConnection ?: return
        val n = Regex("""(?:[\p{L}\p{N}’'_-]+|[^\p{L}\p{N}\s])?\s*$""").find(before(60))?.value?.length ?: 0
        if (n > 0) ic.deleteSurroundingText(n, 0)
        undo = null; gAlt = emptyList(); refresh()
    }

    fun moveCursor(n: Int) {
        val ic = currentInputConnection ?: return
        val c = if (n > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        repeat(abs(n)) { ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, c)); ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, c)) }
        undo = null; refresh()
    }

    fun glide(r: List<String>) {
        val ic = currentInputConnection ?: return
        if (r.isEmpty()) return
        val c = caps(); val cs = { w: String -> if (c) cap(w) else w }
        val b = before(1)
        val pre = if (b.isNotEmpty() && !b.last().isWhitespace() && b.last() !in "([{«") " " else ""
        undo = null
        ic.commitText(pre + cs(r[0]), 1); learn(); ic.commitText(" ", 1)
        gAlt = r.map(cs); gCur = cs(r[0]); if (sh == 1) sh = 0
        refresh()
    }
}
