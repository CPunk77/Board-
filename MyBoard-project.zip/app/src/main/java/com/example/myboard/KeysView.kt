package com.example.myboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Key(val v: String, val a: Char, val w: Float = 1f) { val r = RectF() }

private class T(val k: Key, val x0: Float, val y0: Float) {
    val pts = ArrayList<PointF>()
    val ks = ArrayList<Key>()
    var glide = false; var flick = false; var long = false; var moved = false
    var lx = x0
    var job: Runnable? = null
}

class KeysView(ctx: Context, private val s: BoardService) : View(ctx) {
    private val rows = ArrayList<List<Key>>()
    private val touches = HashMap<Int, T>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val d = ctx.resources.displayMetrics.density
    private var lastShift = 0L
    private val lay = arrayOf(arrayOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю"), arrayOf("qwertyuiop", "asdfghjkl", "zxcvbnm"))
    private val symRows = arrayOf("@#₽_&-+()/", "*«»:;!?%=…", "~<>[]{}|^$")
    private val alt = mapOf("е" to "ё", "ь" to "ъ", "," to "?", "." to "!")
    private val ACC = 0xFFF2B544.toInt(); private val TX = 0xFFEDF1EE.toInt()

    init { rebuild() }

    fun rebuild() {
        rows.clear()
        fun ch(t: String) = t.map { Key(it.toString(), 'c') }
        val l = if (s.sym) symRows else lay[s.lang]
        rows.add("1234567890".map { Key(it.toString(), 'c') })
        rows.add(ch(l[0])); rows.add(ch(l[1]))
        rows.add((if (s.sym) emptyList<Key>() else listOf(Key("⇧", 's', 1.4f))) + ch(l[2]) + Key("⌫", 'b', 1.4f))
        rows.add(listOf(Key(if (s.sym) "abc" else "?!#", 'y', 1.4f), Key(if (s.lang == 0) "RU" else "EN", 'l', 1.2f),
            Key(",", 'c'), Key(" ", ' ', 4.5f), Key(".", 'c'), Key("⏎", 'e', 1.5f)))
        layout(); invalidate()
    }

    private fun layout() {
        if (width == 0) return
        val g = 5 * d; val u = (height - g * 6) / 4.75f; var y = g
        rows.forEachIndexed { i, row ->
            val h = if (i == 0) u * .75f else u
            val tw = row.sumOf { it.w.toDouble() }.toFloat()
            val kw = (width - g * (row.size + 1)) / tw; var x = g
            row.forEach { it.r.set(x, y, x + kw * it.w, y + h); x += kw * it.w + g }
            y += h + g
        }
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layout() }

    private fun label(k: Key): String = when {
        k.a == 'c' && k.v[0].isLetter() && s.caps() -> k.v.uppercase()
        k.a == 's' && s.sh == 2 -> "⇪"
        k.a == ' ' -> if (s.lang == 0) "русский" else "English"
        else -> k.v
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF161D1B.toInt())
        paint.style = Paint.Style.FILL
        for (row in rows) for (k in row) {
            val down = touches.values.any { it.k === k }
            val hot = k.a == 'e' || (k.a == 's' && s.sh != 0)
            paint.color = when {
                hot -> ACC
                k.a == 'c' -> if (down) 0xFF3A4743.toInt() else 0xFF27312E.toInt()
                else -> if (down) 0xFF33403B.toInt() else 0xFF1F2825.toInt()
            }
            c.drawRoundRect(k.r, 9 * d, 9 * d, paint)
            paint.color = if (hot) 0xFF1B1405.toInt() else TX
            paint.textSize = (if (k.a == 'c') 21 else 15) * d
            c.drawText(label(k), k.r.centerX(), k.r.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
        }
        touches.values.firstOrNull { !it.glide && it.k.a == 'c' }?.let { t -> // пузырь над нажатой клавишей
            val k = t.k; val txt = if (t.flick) k.v.uppercase() else if (t.long) (alt[k.v] ?: label(k)) else label(k)
            val b = RectF(k.r.centerX() - 28 * d, k.r.top - 64 * d, k.r.centerX() + 28 * d, k.r.top - 6 * d)
            paint.color = 0xFF3A4743.toInt(); c.drawRoundRect(b, 12 * d, 12 * d, paint)
            paint.color = TX; paint.textSize = 30 * d
            c.drawText(txt, b.centerX(), b.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
        }
        touches.values.firstOrNull { it.glide }?.let { t -> // след свайпа
            val p = Path(); t.pts.forEachIndexed { i, q -> if (i == 0) p.moveTo(q.x, q.y) else p.lineTo(q.x, q.y) }
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 7 * d; paint.strokeCap = Paint.Cap.ROUND
            paint.strokeJoin = Paint.Join.ROUND; paint.color = ACC; paint.alpha = 130
            c.drawPath(p, paint); paint.style = Paint.Style.FILL; paint.alpha = 255
        }
    }

    private fun keyAt(x: Float, y: Float): Key? { // ближайшая клавиша — промахи в зазоры не теряются
        var b: Key? = null; var bd = Float.MAX_VALUE
        for (row in rows) for (k in row) {
            val dx = max(max(k.r.left - x, x - k.r.right), 0f); val dy = max(max(k.r.top - y, y - k.r.bottom), 0f)
            val dd = dx * dx + dy * dy
            if (dd < bd) { bd = dd; b = k }
        }
        return b
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { val i = e.actionIndex; down(e.getPointerId(i), e.getX(i), e.getY(i)) }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> { touches.values.forEach { t -> t.job?.let { removeCallbacks(it) } }; touches.clear() }
        }
        invalidate(); return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        val k = keyAt(x, y) ?: return
        val t = T(k, x, y); t.pts.add(PointF(x, y)); touches[id] = t
        if (k.a == 'c' && k.v[0].isLetter()) t.ks.add(k)
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (k.a == 'b') {
            s.backspace()
            val r = object : Runnable { override fun run() { s.backspace(); postDelayed(this, 55) } }
            t.job = r; postDelayed(r, 380)
        } else if (k.a == 'c' && alt.containsKey(k.v)) {
            val r = Runnable { t.long = true; invalidate() }
            t.job = r; postDelayed(r, 380)
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        val t = touches[id] ?: return; t.pts.add(PointF(x, y)); val k = t.k
        if (k.a == 'c') {
            val kk = keyAt(x, y)
            if (kk != null && kk.a == 'c' && kk.v[0].isLetter() && kk !== t.ks.lastOrNull()) t.ks.add(kk)
            if (!t.glide && t.ks.size >= 3 && k.v[0].isLetter()) { t.glide = true; t.job?.let { removeCallbacks(it) } }
            if (!t.glide && y - t.y0 < -24 * d) { t.flick = true; t.job?.let { removeCallbacks(it) } }
        }
        if (k.a == 'b' && x - t.lx < -36 * d) { t.job?.let { removeCallbacks(it) }; s.backspaceWord(); t.lx = x }
        if (k.a == ' ') {
            val n = ((x - t.lx) / (14 * d)).toInt()
            if (n != 0) { s.moveCursor(n); t.lx += n * 14 * d; t.moved = true }
        }
    }

    private fun up(id: Int) {
        val t = touches.remove(id) ?: return
        t.job?.let { removeCallbacks(it) }; val k = t.k
        when (k.a) {
            'c' -> if (t.glide) s.glide(decode(t.pts)) else s.typeChar(k.v, t.flick, if (t.long && !t.flick) alt[k.v] else null)
            's' -> { val n = SystemClock.uptimeMillis(); s.sh = if (n - lastShift < 350) 2 else if (s.sh != 0) 0 else 1; lastShift = n; s.refresh() }
            ' ' -> if (!t.moved) s.space()
            'l' -> { s.lang = 1 - s.lang; s.sym = false; rebuild(); s.refresh() }
            'y' -> { s.sym = !s.sym; rebuild(); s.refresh() }
            'e' -> s.enter()
        }
    }

    // ---- свайп-печать: сравниваем траекторию пальца с «идеальным» путём каждого слова ----
    private fun rs(p: List<PointF>, n: Int = 24): List<PointF> {
        var len = 0f; val dd = FloatArray(p.size)
        for (i in 1 until p.size) { len += hypot(p[i].x - p[i - 1].x, p[i].y - p[i - 1].y); dd[i] = len }
        if (len == 0f) return List(n) { p[0] }
        val o = ArrayList<PointF>(); var j = 1
        for (i in 0 until n) {
            val st = len * i / (n - 1)
            while (j < p.size - 1 && dd[j] < st) j++
            val q = (st - dd[j - 1]) / max(dd[j] - dd[j - 1], 1e-6f)
            o.add(PointF(p[j - 1].x + (p[j].x - p[j - 1].x) * q, p[j - 1].y + (p[j].y - p[j - 1].y) * q))
        }
        return o
    }

    private fun decode(pts: List<PointF>): List<String> {
        val c = HashMap<Char, PointF>()
        for (row in rows) for (k in row) if (k.a == 'c' && k.v[0].isLetter()) c[k.v[0]] = PointF(k.r.centerX(), k.r.centerY())
        if (c.isEmpty() || pts.size < 2) return emptyList()
        val kw = rows[1][0].r.width(); val g = rs(pts); val st = pts.first(); val en = pts.last()
        val res = ArrayList<Pair<Float, String>>()
        s.words().forEachIndexed { i, wd ->
            if (wd.length < 2) return@forEachIndexed
            val f = c[wd[0]] ?: return@forEachIndexed
            val l = c[wd.last()] ?: return@forEachIndexed
            if (hypot(f.x - st.x, f.y - st.y) > kw * 1.7f || hypot(l.x - en.x, l.y - en.y) > kw * 1.7f) return@forEachIndexed
            if (wd.any { !c.containsKey(it) }) return@forEachIndexed
            val pa = ArrayList<PointF>()
            for (ch in wd) { val q = c[ch]!!; if (pa.lastOrNull() !== q) pa.add(q) }
            val ip = rs(pa); var z = 0f
            for (j in 0 until 24) z += hypot(g[j].x - ip[j].x, g[j].y - ip[j].y)
            res.add(Pair(z / 24 / kw + min(i, 2000) * .0002f - min(s.user[wd] ?: 0, 10) * .04f, wd))
        }
        return res.sortedBy { it.first }.take(3).map { it.second }
    }
}
