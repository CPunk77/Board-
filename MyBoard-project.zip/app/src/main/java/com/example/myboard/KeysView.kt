package com.example.myboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Key(val v: String, val a: Char, val w: Float = 1f, val hint: String = "") { val r = RectF() }

private class T(val k: Key, val x0: Float, val y0: Float) {
    val pts = ArrayList<PointF>()
    val ks = ArrayList<Key>()
    var glide = false; var flick = false; var dn = false; var long = false; var moved = false
    var lx = x0
    var job: Runnable? = null
}

class KeysView(ctx: Context, private val s: BoardService) : View(ctx) {
    private val rows = ArrayList<List<Key>>()
    private val touches = HashMap<Int, T>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val d = ctx.resources.displayMetrics.density
    private var lastShift = 0L
    private var hasNum = true
    private val DARK = 0xFF1B1405.toInt()
    private val lay = arrayOf(arrayOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю"), arrayOf("qwertyuiop", "asdfghjkl", "zxcvbnm"))
    private val symRows = arrayOf("@#₽_&-+()/", "*«»:;!?%=…", "~<>[]{}|^$")
    private val hintRu = arrayOf("1234567890-", "@#₽%&+()/_*", "!?;:\"'=~…")
    private val hintEn = arrayOf("1234567890", "@#$%&+()/", "!?;:\"'_")
    private val alt = mapOf("е" to "ё", "ь" to "ъ", "," to "?", "." to "!")

    init { rebuild() }

    fun rebuild() {
        rows.clear(); hasNum = Cfg.num
        val hs = if (s.lang == 0) hintRu else hintEn
        fun ch(t: String, h: String) = t.mapIndexed { i, c -> Key(c.toString(), 'c', 1f, if (s.sym) "" else (h.getOrNull(i)?.toString() ?: "")) }
        val l = if (s.sym) symRows else lay[s.lang]
        if (hasNum) rows.add("1234567890".map { Key(it.toString(), 'c') })
        rows.add(ch(l[0], hs[0])); rows.add(ch(l[1], hs[1]))
        rows.add((if (s.sym) emptyList<Key>() else listOf(Key("⇧", 's', 1.4f))) + ch(l[2], hs[2]) + Key("⌫", 'b', 1.4f))
        rows.add(listOf(Key(if (s.sym) "abc" else "?!#", 'y', 1.4f), Key(if (s.lang == 0) "RU" else "EN", 'l', 1.2f),
            Key(",", 'c'), Key(" ", ' ', 4.5f), Key(".", 'c'), Key("⏎", 'e', 1.5f)))
        layout(); invalidate()
    }

    private fun layout() {
        if (width == 0) return
        val g = 5 * d; val u = (height - g * (rows.size + 1)) / (if (hasNum) 4.75f else 4f); var y = g
        rows.forEachIndexed { i, row ->
            val h = if (hasNum && i == 0) u * .75f else u
            val tw = row.sumOf { it.w.toDouble() }.toFloat()
            val kw = (width - g * (row.size + 1)) / tw; var x = g
            row.forEach { it.r.set(x, y, x + kw * it.w, y + h); x += kw * it.w + g }
            y += h + g
        }
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layout() }

    private fun label(k: Key): String = when {
        k.a == 'c' && k.v[0].isLetter() && s.caps() -> k.v.uppercase()
        k.a == 's' && s.sh == 2 -> "⇪"
        k.a == ' ' -> if (s.lang == 0) "русский" else "English"
        else -> k.v
    }

    private fun mix(a: Int, b: Int, f: Float) = Color.rgb(
        (Color.red(a) * (1 - f) + Color.red(b) * f).toInt(),
        (Color.green(a) * (1 - f) + Color.green(b) * f).toInt(),
        (Color.blue(a) * (1 - f) + Color.blue(b) * f).toInt())

    override fun onDraw(c: Canvas) {
        val th = Cfg.theme; val tint = if (Color.red(th.bg) < 128) Color.WHITE else Color.BLACK; val rad = Cfg.r * d
        paint.style = Paint.Style.FILL; paint.color = th.bg
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        for (row in rows) for (k in row) {
            val down = touches.values.any { it.k === k }
            val hot = k.a == 'e' || (k.a == 's' && s.sh != 0)
            val base = if (k.a == 'c') th.key else th.fn
            paint.color = if (hot) Cfg.accent else if (down) mix(base, tint, .14f) else base
            c.drawRoundRect(k.r, rad, rad, paint)
            paint.color = if (hot) DARK else th.tx
            paint.textSize = (if (k.a == 'c') 21 else 15) * d
            c.drawText(label(k), k.r.centerX(), k.r.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
            if (Cfg.hints && k.hint.isNotEmpty()) {
                paint.color = th.sub; paint.textSize = 10 * d
                c.drawText(k.hint, k.r.right - 7 * d, k.r.top + 12 * d, paint)
            }
        }
        touches.values.firstOrNull { !it.glide && it.k.a == 'c' }?.let { t ->
            val k = t.k
            val txt = if (t.dn) k.hint else if (t.flick) k.v.uppercase() else if (t.long) (alt[k.v] ?: label(k)) else label(k)
            val b = RectF(k.r.centerX() - 28 * d, k.r.top - 64 * d, k.r.centerX() + 28 * d, k.r.top - 6 * d)
            paint.color = mix(th.key, tint, .2f); c.drawRoundRect(b, 12 * d, 12 * d, paint)
            paint.color = th.tx; paint.textSize = 30 * d
            c.drawText(txt, b.centerX(), b.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
        }
        touches.values.firstOrNull { it.glide }?.let { t ->
            val p = Path(); t.pts.forEachIndexed { i, q -> if (i == 0) p.moveTo(q.x, q.y) else p.lineTo(q.x, q.y) }
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 7 * d; paint.strokeCap = Paint.Cap.ROUND
            paint.strokeJoin = Paint.Join.ROUND; paint.color = Cfg.accent; paint.alpha = 130
            c.drawPath(p, paint); paint.style = Paint.Style.FILL; paint.alpha = 255
        }
    }

    private fun gap(k: Key, x: Float, y: Float): Float {
        val dx = max(max(k.r.left - x, x - k.r.right), 0f); val dy = max(max(k.r.top - y, y - k.r.bottom), 0f)
        return dx * dx + dy * dy
    }

    private fun keyAt(x: Float, y: Float): Key? {
        var b: Key? = null; var bd = Float.MAX_VALUE
        for (row in rows) for (k in row) { val dd = gap(k, x, y); if (dd < bd) { bd = dd; b = k } }
        return b
    }

    // Умное попадание: рядом лежащие буквы сравниваются по расстоянию и по тому, продолжается ли слово из словаря
    private fun smart(x: Float, y: Float, k: Key): Key {
        if (!k.v[0].isLetter()) return k
        val p = s.prefix(); val kw = k.r.width(); var best = k; var bs = Float.MAX_VALUE
        for (row in rows) for (c in row) if (c.a == 'c' && c.v[0].isLetter()) {
            val dd = gap(c, x, y) / (kw * kw)
            if (dd > .25f) continue
            val sc = dd + (if (s.isPrefix(p + c.v)) 0f else .3f)
            if (sc < bs) { bs = sc; best = c }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { val i = e.actionIndex; down(e.getPointerId(i), e.getX(i), e.getY(i)) }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> { touches.values.forEach { t -> t.job?.let { removeCallbacks(it) } }; touches.clear() }
        }
        invalidate(); return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        val k = keyAt(x, y) ?: return
        val t = T(k, x, y); t.pts.add(PointF(x, y)); touches[id] = t
        if (k.a == 'c' && k.v[0].isLetter()) t.ks.add(k)
        if (Cfg.vib) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (k.a == 'b') {
            s.backspace()
            val r = object : Runnable { override fun run() { s.backspace(); postDelayed(this, 55) } }
            t.job = r; postDelayed(r, 380)
        } else if (k.a == 'c' && alt.containsKey(k.v)) {
            val r = Runnable { t.long = true; invalidate() }
            t.job = r; postDelayed(r, 380)
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        val t = touches[id] ?: return; t.pts.add(PointF(x, y)); val k = t.k
        if (k.a == 'c') {
            val kk = keyAt(x, y)
            if (kk != null && kk.a == 'c' && kk.v[0].isLetter() && kk !== t.ks.lastOrNull()) t.ks.add(kk)
            if (Cfg.glide && !t.glide && t.ks.size >= 3 && k.v[0].isLetter()) { t.glide = true; t.job?.let { removeCallbacks(it) } }
            if (!t.glide && y - t.y0 < -24 * d) { t.flick = true; t.dn = false; t.job?.let { removeCallbacks(it) } }
            if (!t.glide && Cfg.hints && k.hint.isNotEmpty() && y - t.y0 > 24 * d) { t.dn = true; t.flick = false; t.job?.let { removeCallbacks(it) } }
        }
        if (k.a == 'b' && x - t.lx < -36 * d) { t.job?.let { removeCallbacks(it) }; s.backspaceWord(); t.lx = x }
        if (k.a == ' ') {
            val n = ((x - t.lx) / (14 * d)).toInt()
            if (n != 0) { s.moveCursor(n); t.lx += n * 14 * d; t.moved = true }
            t.flick = !t.moved && y - t.y0 < -30 * d
        }
    }

    private fun up(id: Int) {
        val t = touches.remove(id) ?: return
        t.job?.let { removeCallbacks(it) }; val k = t.k
        when (k.a) {
            'c' -> when {
                t.glide -> s.glide(decode(t.pts))
                t.dn -> s.typeChar(k.hint, false, null)
                t.flick || t.long -> s.typeChar(k.v, t.flick, if (t.long && !t.flick) alt[k.v] else null)
                else -> s.typeChar((if (Cfg.smart) smart(t.x0, t.y0, k) else k).v, false, null)
            }
            's' -> { val n = SystemClock.uptimeMillis(); s.sh = if (n - lastShift < 350) 2 else if (s.sh != 0) 0 else 1; lastShift = n; s.refresh() }
            ' ' -> if (t.flick) { s.lang = 1 - s.lang; s.sym = false; rebuild(); s.refresh() } else if (!t.moved) s.space()
            'l' -> { s.lang = 1 - s.lang; s.sym = false; rebuild(); s.refresh() }
            'y' -> { s.sym = !s.sym; rebuild(); s.refresh() }
            'e' -> s.enter()
        }
    }

    private fun rs(p: List<PointF>, n: Int = 24): List<PointF> {
        var len = 0f; val dd = FloatArray(p.size)
        for (i in 1 until p.size) { len += hypot(p[i].x - p[i - 1].x, p[i].y - p[i - 1].y); dd[i] = len }
        if (len == 0f) return List(n) { p[0] }
        val o = ArrayList<PointF>(); var j = 1
        for (i in 0 until n) {
            val st = len * i / (n - 1)
            while (j < p.size - 1 && dd[j] < st) j++
            val q = (st - dd[j - 1]) / max(dd[j] - dd[j - 1], 1e-6f)
            o.add(PointF(p[j - 1].x + (p[j].x - p[j - 1].x) * q, p[j - 1].y + (p[j].y - p[j - 1].y) * q))
        }
        return o
    }

    private fun decode(pts: List<PointF>): List<String> {
        val c = HashMap<Char, PointF>()
        for (row in rows) for (k in row) if (k.a == 'c' && k.v[0].isLetter()) c[k.v[0]] = PointF(k.r.centerX(), k.r.centerY())
        if (c.isEmpty() || pts.size < 2) return emptyList()
        val kw = rows[rows.size - 4][0].r.width(); val g = rs(pts); val st = pts.first(); val en = pts.last()
        val res = ArrayList<Pair<Float, String>>()
        s.words().forEachIndexed { i, wd ->
            if (wd.length < 2) return@forEachIndexed
            val f = c[wd[0]] ?: return@forEachIndexed
            val l = c[wd.last()] ?: return@forEachIndexed
            if (hypot(f.x - st.x, f.y - st.y) > kw * 1.7f || hypot(l.x - en.x, l.y - en.y) > kw * 1.7f) return@forEachIndexed
            if (wd.any { !c.containsKey(it) }) return@forEachIndexed
            val pa = ArrayList<PointF>()
            for (ch in wd) { val q = c[ch]!!; if (pa.lastOrNull() !== q) pa.add(q) }
            val ip = rs(pa); var z = 0f
            for (j in 0 until 24) z += hypot(g[j].x - ip[j].x, g[j].y - ip[j].y)
            res.add(Pair(z / 24 / kw + min(i, 2000) * .0002f - min(s.user[wd] ?: 0, 10) * .04f, wd))
        }
        return res.sortedBy { it.first }.take(3).map { it.second }
    }
}
